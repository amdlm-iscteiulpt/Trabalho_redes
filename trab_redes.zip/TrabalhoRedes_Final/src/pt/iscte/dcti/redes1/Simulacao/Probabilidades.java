package pt.iscte.dcti.redes1.Simulacao;

public class Probabilidades {

	public double Pse;
	public double erros;
	public 	double Pnd_e;
	public double Pcc_e;
	public Probabilidades(double pse, double erros, double pnd_e, double pcc_e) {
		super();
		Pse = pse;
		this.erros = erros;
		Pnd_e = pnd_e;
		Pcc_e = pcc_e;
	}
	
	
}
